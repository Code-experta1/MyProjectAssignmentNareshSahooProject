package com.assignment.naresh.sahoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrystalSaasApplicationTests {
    @Test
    void contextLoads() {
    }
}
