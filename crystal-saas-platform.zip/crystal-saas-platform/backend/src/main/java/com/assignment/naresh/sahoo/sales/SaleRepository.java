package com.assignment.naresh.sahoo.sales;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;

public interface SaleRepository extends JpaRepository<Sale, Long> {
    Page<Sale> findBySaleDateBetween(LocalDate start, LocalDate end, Pageable pageable);
}
