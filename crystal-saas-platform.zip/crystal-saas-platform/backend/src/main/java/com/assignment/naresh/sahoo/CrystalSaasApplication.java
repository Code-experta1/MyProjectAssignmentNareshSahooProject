package com.assignment.naresh.sahoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrystalSaasApplication {
    public static void main(String[] args) {
        SpringApplication.run(CrystalSaasApplication.class, args);
    }
}
