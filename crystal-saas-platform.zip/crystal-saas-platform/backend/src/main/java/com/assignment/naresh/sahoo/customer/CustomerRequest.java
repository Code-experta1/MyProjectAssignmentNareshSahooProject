package com.assignment.naresh.sahoo.customer;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public class CustomerRequest {
    @NotBlank(message = "Name is required")
    @Size(max = 100)
    private String name;
    @NotBlank(message = "Company is required")
    @Size(max = 120)
    private String company;
    @NotBlank(message = "Email is required")
    @Email(message = "Enter a valid email address")
    private String email;
    @NotBlank(message = "Phone is required")
    @Pattern(regexp = "^[+]?[0-9() .-]{7,20}$", message = "Enter a valid phone number")
    private String phone;
    @NotNull(message = "Receivables is required")
    @DecimalMin(value = "0.00", message = "Receivables cannot be negative")
    private BigDecimal receivables;

    public String getName() { return name; }
    public String getCompany() { return company; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public BigDecimal getReceivables() { return receivables; }
    public void setName(String name) { this.name = name; }
    public void setCompany(String company) { this.company = company; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setReceivables(BigDecimal receivables) { this.receivables = receivables; }
}
