package com.assignment.naresh.sahoo.customer;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.NoSuchElementException;

@Service
public class CustomerService {
    private final CustomerRepository repository;

    public CustomerService(CustomerRepository repository) {
        this.repository = repository;
    }

    public Page<CustomerResponse> findAll(int page, int size, String search) {
        PageRequest pageable = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by("id").descending());
        Page<Customer> customers;
        if (search == null || search.isBlank()) {
            customers = repository.findAll(pageable);
        } else {
            String term = search.trim();
            customers = repository.findByNameContainingIgnoreCaseOrCompanyContainingIgnoreCaseOrEmailContainingIgnoreCase(
                    term, term, term, pageable);
        }
        return customers.map(this::toResponse);
    }

    public CustomerResponse findById(Long id) {
        return toResponse(repository.findById(id).orElseThrow(() -> new NoSuchElementException("Customer not found")));
    }

    @Transactional
    public CustomerResponse create(CustomerRequest request) {
        if (repository.existsByEmailIgnoreCase(request.getEmail())) {
            throw new IllegalArgumentException("A customer with this email already exists");
        }
        Customer customer = new Customer(request.getName().trim(), request.getCompany().trim(),
                request.getEmail().trim().toLowerCase(), request.getPhone().trim(), request.getReceivables());
        return toResponse(repository.save(customer));
    }

    @Transactional
    public CustomerResponse update(Long id, CustomerRequest request) {
        Customer customer = repository.findById(id).orElseThrow(() -> new NoSuchElementException("Customer not found"));
        if (repository.existsByEmailIgnoreCaseAndIdNot(request.getEmail(), id)) {
            throw new IllegalArgumentException("A customer with this email already exists");
        }
        customer.setName(request.getName().trim());
        customer.setCompany(request.getCompany().trim());
        customer.setEmail(request.getEmail().trim().toLowerCase());
        customer.setPhone(request.getPhone().trim());
        customer.setReceivables(request.getReceivables());
        return toResponse(repository.save(customer));
    }

    @Transactional
    public void delete(Long id) {
        Customer customer = repository.findById(id).orElseThrow(() -> new NoSuchElementException("Customer not found"));
        repository.delete(customer);
    }

    private CustomerResponse toResponse(Customer customer) {
        return new CustomerResponse(customer.getId(), customer.getName(), customer.getCompany(),
                customer.getEmail(), customer.getPhone(), customer.getReceivables());
    }
}
