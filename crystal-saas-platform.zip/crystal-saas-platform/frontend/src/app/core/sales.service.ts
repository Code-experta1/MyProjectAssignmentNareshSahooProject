import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PageResponse, Sale } from '../models/sale.model';

@Injectable({ providedIn: 'root' })
export class SalesService {
  private readonly api = 'http://localhost:8080/api/sales';
  constructor(private http: HttpClient) {}

  getSummary(period: string, month: string): Observable<any> {
    let params = new HttpParams().set('period', period).set('month', month);
    return this.http.get(`${this.api}/summary`, { params });
  }

  getReports(page: number, size: number, period: string, month: string): Observable<PageResponse<Sale>> {
    let params = new HttpParams().set('page', page).set('size', size).set('period', period).set('month', month);
    return this.http.get<PageResponse<Sale>>(`${this.api}/reports`, { params });
  }
}
