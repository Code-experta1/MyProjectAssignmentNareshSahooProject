import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class DashboardService {
  private readonly api = 'http://localhost:8080/api/dashboard';
  constructor(private http: HttpClient) {}

  getSummary(period: string): Observable<any> {
    return this.http.get(`${this.api}/summary`, { params: new HttpParams().set('period', period) });
  }

  getRevenue(period: string): Observable<any> {
    return this.http.get(`${this.api}/revenue`, { params: new HttpParams().set('period', period) });
  }

  getSatisfaction(period: string): Observable<any> {
    return this.http.get(`${this.api}/satisfaction`, { params: new HttpParams().set('period', period) });
  }
}
