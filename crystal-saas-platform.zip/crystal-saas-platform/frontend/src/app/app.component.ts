import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  collapsed = false;
  darkMode = false;
  searchText = '';

  toggleSidebar(): void {
    this.collapsed = !this.collapsed;
  }

  toggleTheme(): void {
    this.darkMode = !this.darkMode;
    document.body.classList.toggle('dark-theme', this.darkMode);
  }
}
