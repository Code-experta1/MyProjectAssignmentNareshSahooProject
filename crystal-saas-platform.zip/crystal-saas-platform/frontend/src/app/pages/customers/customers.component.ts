import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerService } from '../../core/customer.service';
import { Customer, CustomerRequest } from '../../models/customer.model';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html'
})
export class CustomersComponent implements OnInit {
  readonly Math = Math;

  customers: Customer[] = [];
  form: FormGroup;
  showForm = false;
  editingId: number | null = null;
  page = 0;
  size = 10;
  totalElements = 0;
  totalPages = 0;
  search = '';
  loading = false;
  error = '';
  success = '';
  selectedIds = new Set<number>();

  constructor(private customerService: CustomerService, private formBuilder: FormBuilder) {
    this.form = this.formBuilder.group({
      name: ['', [Validators.required, Validators.maxLength(100)]],
      company: ['', [Validators.required, Validators.maxLength(120)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern(/^[+]?[0-9() .-]{7,20}$/)]],
      receivables: [0, [Validators.required, Validators.min(0)]]
    });
  }

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading = true;
    this.error = '';
    this.customerService.getCustomers(this.page, this.size, this.search).subscribe({
      next: response => {
        this.customers = response.content;
        this.totalElements = response.totalElements;
        this.totalPages = response.totalPages;
        this.loading = false;
        this.selectedIds.clear();
      },
      error: error => {
        this.error = error.message || 'Unable to load customers. Check that the backend is running.';
        this.loading = false;
      }
    });
  }

  searchCustomers(): void { this.page = 0; this.load(); }

  openCreate(): void {
    this.editingId = null;
    this.form.reset({ name: '', company: '', email: '', phone: '', receivables: 0 });
    this.showForm = true;
    this.success = '';
    this.error = '';
  }

  openEdit(customer: Customer): void {
    this.editingId = customer.id;
    this.form.reset({
      name: customer.name, company: customer.company, email: customer.email,
      phone: customer.phone, receivables: customer.receivables
    });
    this.showForm = true;
    this.success = '';
    this.error = '';
  }

  closeForm(): void { this.showForm = false; }

  save(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const value = this.form.getRawValue() as CustomerRequest;
    const request = this.editingId === null
      ? this.customerService.createCustomer(value)
      : this.customerService.updateCustomer(this.editingId, value);
    request.subscribe({
      next: () => {
        this.showForm = false;
        this.success = this.editingId === null ? 'Customer created successfully.' : 'Customer updated successfully.';
        this.load();
      },
      error: error => this.error = error.message || 'Unable to save customer.'
    });
  }

  deleteCustomer(customer: Customer): void {
    if (!window.confirm(`Delete ${customer.name}? This action cannot be undone.`)) return;
    this.customerService.deleteCustomer(customer.id).subscribe({
      next: () => {
        this.success = 'Customer deleted successfully.';
        if (this.customers.length === 1 && this.page > 0) this.page--;
        this.load();
      },
      error: error => this.error = error.message || 'Unable to delete customer.'
    });
  }

  previousPage(): void { if (this.page > 0) { this.page--; this.load(); } }
  nextPage(): void { if (this.page + 1 < this.totalPages) { this.page++; this.load(); } }

  get allSelected(): boolean {
    return this.customers.length > 0 && this.customers.every(customer => this.selectedIds.has(customer.id));
  }

  toggleAll(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.customers.forEach(customer => checked ? this.selectedIds.add(customer.id) : this.selectedIds.delete(customer.id));
  }

  toggleOne(id: number, event: Event): void {
    if ((event.target as HTMLInputElement).checked) this.selectedIds.add(id);
    else this.selectedIds.delete(id);
  }

  hasError(field: string, error: string): boolean {
    const control = this.form.get(field);
    return !!control && control.touched && control.hasError(error);
  }
}
