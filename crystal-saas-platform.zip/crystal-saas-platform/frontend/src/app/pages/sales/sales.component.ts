import { Component, OnInit } from '@angular/core';
import { SalesService } from '../../core/sales.service';
import { Sale } from '../../models/sale.model';

@Component({
  selector: 'app-sales',
  templateUrl: './sales.component.html'
})
export class SalesComponent implements OnInit {
  readonly Math = Math;

  period = 'week';
  month = new Date().toISOString().slice(0, 7);
  page = 0;
  size = 10;
  totalElements = 0;
  totalPages = 0;
  sales: Sale[] = [];
  selectedIds = new Set<number>();
  summary: any = {};
  loading = false;
  error = '';

  constructor(private salesService: SalesService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading = true;
    this.error = '';
    this.salesService.getReports(this.page, this.size, this.period, this.month).subscribe({
      next: response => {
        this.sales = response.content;
        this.totalElements = response.totalElements;
        this.totalPages = response.totalPages;
        this.loading = false;
        this.selectedIds.clear();
      },
      error: () => { this.error = 'Unable to load sales reports. Check that the backend is running.'; this.loading = false; }
    });
    this.salesService.getSummary(this.period, this.month).subscribe({
      next: response => this.summary = response,
      error: () => this.error = 'Unable to load sales summary.'
    });
  }

  changePeriod(period: string): void {
    this.period = period;
    this.page = 0;
    this.load();
  }

  previousPage(): void {
    if (this.page > 0) { this.page--; this.load(); }
  }

  nextPage(): void {
    if (this.page + 1 < this.totalPages) { this.page++; this.load(); }
  }

  get allSelected(): boolean {
    return this.sales.length > 0 && this.sales.every(sale => this.selectedIds.has(sale.id));
  }

  toggleAll(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    this.sales.forEach(sale => checked ? this.selectedIds.add(sale.id) : this.selectedIds.delete(sale.id));
  }

  toggleOne(id: number, event: Event): void {
    if ((event.target as HTMLInputElement).checked) this.selectedIds.add(id);
    else this.selectedIds.delete(id);
  }

  exportCsv(): void {
    const rows = this.sales.filter(sale => this.selectedIds.size === 0 || this.selectedIds.has(sale.id));
    const header = ['Invoice', 'Customer', 'Date', 'Channel', 'Status', 'Amount'];
    const lines = [header.join(','), ...rows.map(sale => [sale.invoiceNumber, sale.customerName, sale.saleDate, sale.channel, sale.status, sale.amount].map(value => `"${String(value).replace(/"/g, '""')}"`).join(','))];
    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'sales-reports.csv';
    link.click();
    URL.revokeObjectURL(url);
  }

  viewSale(sale: Sale): void {
    window.alert(`${sale.invoiceNumber}\n${sale.customerName}\n${sale.status}\n${sale.amount.toLocaleString()}`);
  }
}
