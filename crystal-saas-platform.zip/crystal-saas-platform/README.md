# Crystal SaaS Platform

A full-stack business dashboard built with Angular and Spring Boot.

## Functionality

- Dashboard: summary cards, weekly revenue chart, customer satisfaction chart, and week filter.
- Sales: KPI cards, report filters, month selection, row selection, pagination, and CSV export.
- Customers: searchable customer table, create/edit/delete operations, field validation, row selection, and pagination.
- Shared interface: collapsible sidebar, navigation groups, dark mode, quick actions, search field, notifications, and responsive layout.
- Backend: REST APIs, DTOs, validation, JPA repositories, global error handling, H2 database, and startup sample data.

## Requirements

- Java 17+
- Maven 3.9+
- Node.js 18+
- npm 9+

## Run the backend

Open a terminal in `backend` and run:

```bash
mvn spring-boot:run
```

The API starts at `http://localhost:8080`. H2 data is stored in memory and sample records are loaded at startup. H2 console: `http://localhost:8080/h2-console`, JDBC URL `jdbc:h2:mem:crystaldb`, username `sa`, password empty.

## Run the frontend

Open another terminal in `frontend` and run:

```bash
npm install
npm start
```

Open `http://localhost:4200`.

## API endpoints

### Customers
- `GET /api/customers?page=0&size=10&search=`
- `GET /api/customers/{id}`
- `POST /api/customers`
- `PUT /api/customers/{id}`
- `DELETE /api/customers/{id}`

### Sales
- `GET /api/sales/summary?period=week&month=2026-10`
- `GET /api/sales/reports?page=0&size=10&period=week&month=2026-10`

### Dashboard
- `GET /api/dashboard/summary?period=week`
- `GET /api/dashboard/revenue?period=week`
- `GET /api/dashboard/satisfaction?period=week`

## Assumptions

- Sales and dashboard data use representative sample records because no source system or final design assets were supplied.
- The unclear comparison amount in the design is represented with a clear percentage comparison.
- Sales report filters are client-facing controls backed by query parameters.
- Customer receivables are stored as decimal amounts.
- H2 is used to make the backend runnable without separate database installation.

## Architecture

Angular uses feature pages, shared layout components, typed models, API services, an HTTP interceptor, and reactive forms. Spring Boot uses Controller, Service, Repository, Entity, DTO, and exception layers.

## Ticket plan

1. Create the shared application shell and responsive navigation.
2. Implement dashboard cards, charts, and period filter.
3. Implement sales KPIs, filters, table, pagination, and export.
4. Implement customer CRUD and validation.
5. Create customer, sales, and dashboard REST APIs.
6. Seed sample data and add error handling.
7. Integrate frontend and backend.
8. Verify the run instructions and document assumptions.

Create these tickets in Jira or Trello and share the board with view-only access before submission.

## Improvements with more time

- Add authentication and role-based permissions.
- Add integration and end-to-end tests.
- Replace sample dashboard data with reporting queries.
- Add sorting, server-side date range filters, and configurable page sizes.
- Deploy the frontend and backend and configure production database credentials.
